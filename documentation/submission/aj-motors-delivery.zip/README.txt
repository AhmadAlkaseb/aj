AJ MOTORS - DELIVERY PACKAGE

Report.pdf includes appendices A-E.
Assignment 1 and 2: upload Report.pdf, the matching .pptx and repository link to itsLearning.
Final project: upload Report.pdf, repository link and installation procedure to WISEflow.
The .pdf slide previews are optional reading copies; .pptx files are editable.
aj-motors-source.zip contains current local source, excluding ignored runtime secrets/caches.

Remaining account steps: register owned GitHub OAuth app and run the setup in EXTERNAL-LOGIN.md;
complete a real external login, publish source and retain actual CI run links,
confirm individual reflection/contribution evidence and upload receipts.
Local verification does not assert GitHub publication, cloud deployment or completed external login.
